﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formfilling
{

    public partial class Form2 : Form
    {
        private object myInt;

        public Form2()
        {
            InitializeComponent();
        }

        private void Next2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Nama Pengirim :" + pengirim.Text +
                "\n Alamat Pengirim :" + almtpengirim.Text +
                "\n Kode Pos :" + kppengirim.Text +
                "\n No. Tlp / HP :" + nopengirim.Text +
                "\n \n Nama Penerima :" + penerima.Text +
                "\n Alamat Penerima :" + almtpenerima.Text +
                "\n Kode Pos :" + kppenerima.Text +
                "\n No. Tlp / HP:" + nopenerima.Text +
                "\n \n Nama Barang :" + barang.Text +
                "\n Berat :" + berat.Text +
                "\n Biaya barang Perkilo :" + biaya.Text +
                "\n Total Biaya Pengiriman :" + total.Text, "RICIAN PENGIRIMAN" ,
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void back1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void barang_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void biaya_TextChanged(object sender, EventArgs e)
        {
  
        }

        private void total_TextChanged(object sender, EventArgs e)
        {

        }

        private void hitung_Click(object sender, EventArgs e)
        {
            float berat, biaya, total;
            berat = float.Parse(this.berat.Text);
            biaya = float.Parse(this.biaya.Text);
            total = berat * biaya;
            this.total.Text = Convert.ToString(total);

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
