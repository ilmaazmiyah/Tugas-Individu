﻿namespace tugasopsional
{
    internal class Dim
    {
    }
}