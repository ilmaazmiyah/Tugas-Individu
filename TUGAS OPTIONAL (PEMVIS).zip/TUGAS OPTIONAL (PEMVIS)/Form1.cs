﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugasopsional
{
  
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strinstansi = " ";
            string strkelas = " ";

            //instansi yang dipilih
            if(SD.Checked == true)
            {
                strinstansi = "SD";
            }
            else if(SMP.Checked == true)
            {
                strinstansi = "SMP";
            }
            else if(SMA.Checked == true)
            {
                strinstansi = "SMA";
            }

            // kelas yang dipilih
            if (reguler.Checked == true)
            {
                strkelas = "Reguler";
            }
            else if(unggulan.Checked == true)
            {
                strkelas = "Unggulan";
            }
            //menampilkan
            MessageBox.Show("Nama                     :" + name.Text + 
                         "\n Tempat Tanggal lahir :" + tanggal.Text +
                         "\n Alamat                   : " + almt.Text +
                         "\n Agama                    : " + agm.Text +
                         "\n Jenis Kelamin            : " + jenis.Text +
                         "\n Asal Sekolah             : " + asl.Text +
                         "\n Instansi yang dipilih    :" + strinstansi  +
                         "\n Kelas yang dipilih       : " + strkelas , "data siswa",
                MessageBoxButtons.OK);
        }

        private void SMP_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void nama_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void data_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'tugasoptionalDataSet.Table1' table. You can move, or remove it, as needed.
            this.table1TableAdapter.Fill(this.tugasoptionalDataSet.Table1);

        }
    }
}
