﻿namespace tugasopsional
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.nama = new System.Windows.Forms.Label();
            this.ttl = new System.Windows.Forms.Label();
            this.alamat = new System.Windows.Forms.Label();
            this.agama = new System.Windows.Forms.Label();
            this.jk = new System.Windows.Forms.Label();
            this.asal = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.tanggal = new System.Windows.Forms.TextBox();
            this.almt = new System.Windows.Forms.TextBox();
            this.agm = new System.Windows.Forms.ComboBox();
            this.jenis = new System.Windows.Forms.ComboBox();
            this.asl = new System.Windows.Forms.TextBox();
            this.instansi = new System.Windows.Forms.Label();
            this.SD = new System.Windows.Forms.CheckBox();
            this.SMP = new System.Windows.Forms.CheckBox();
            this.SMA = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.reguler = new System.Windows.Forms.CheckBox();
            this.unggulan = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.table1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tugasoptionalDataSet = new tugasopsional.tugasoptionalDataSet();
            this.table1TableAdapter = new tugasopsional.tugasoptionalDataSetTableAdapters.Table1TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tugasoptionalDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Adobe Gothic Std B", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(185, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(396, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "HALAMAN PPDB ONLINE TAHUN AJARAN 2020 / 2021";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // nama
            // 
            this.nama.AutoSize = true;
            this.nama.Location = new System.Drawing.Point(45, 57);
            this.nama.Name = "nama";
            this.nama.Size = new System.Drawing.Size(96, 13);
            this.nama.TabIndex = 1;
            this.nama.Text = "Nama Calon Siswa";
            this.nama.Click += new System.EventHandler(this.nama_Click);
            // 
            // ttl
            // 
            this.ttl.AutoSize = true;
            this.ttl.Location = new System.Drawing.Point(44, 86);
            this.ttl.Name = "ttl";
            this.ttl.Size = new System.Drawing.Size(111, 13);
            this.ttl.TabIndex = 2;
            this.ttl.Text = "Tempat Tanggal Lahir";
            // 
            // alamat
            // 
            this.alamat.AutoSize = true;
            this.alamat.Location = new System.Drawing.Point(45, 113);
            this.alamat.Name = "alamat";
            this.alamat.Size = new System.Drawing.Size(39, 13);
            this.alamat.TabIndex = 3;
            this.alamat.Text = "Alamat";
            // 
            // agama
            // 
            this.agama.AutoSize = true;
            this.agama.Location = new System.Drawing.Point(45, 150);
            this.agama.Name = "agama";
            this.agama.Size = new System.Drawing.Size(40, 13);
            this.agama.TabIndex = 4;
            this.agama.Text = "Agama";
            // 
            // jk
            // 
            this.jk.AutoSize = true;
            this.jk.Location = new System.Drawing.Point(44, 176);
            this.jk.Name = "jk";
            this.jk.Size = new System.Drawing.Size(71, 13);
            this.jk.TabIndex = 5;
            this.jk.Text = "Jenis Kelamin";
            this.jk.Click += new System.EventHandler(this.label6_Click);
            // 
            // asal
            // 
            this.asal.AutoSize = true;
            this.asal.Location = new System.Drawing.Point(44, 202);
            this.asal.Name = "asal";
            this.asal.Size = new System.Drawing.Size(69, 13);
            this.asal.TabIndex = 6;
            this.asal.Text = "Asal Sekolah";
            this.asal.Click += new System.EventHandler(this.label7_Click);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(183, 50);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(157, 20);
            this.name.TabIndex = 7;
            this.name.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tanggal
            // 
            this.tanggal.Location = new System.Drawing.Point(183, 79);
            this.tanggal.Name = "tanggal";
            this.tanggal.Size = new System.Drawing.Size(155, 20);
            this.tanggal.TabIndex = 8;
            // 
            // almt
            // 
            this.almt.Location = new System.Drawing.Point(181, 113);
            this.almt.Name = "almt";
            this.almt.Size = new System.Drawing.Size(157, 20);
            this.almt.TabIndex = 9;
            // 
            // agm
            // 
            this.agm.FormattingEnabled = true;
            this.agm.Items.AddRange(new object[] {
            "Islam",
            "Kristen",
            "Hindu",
            "Budha",
            "Konghuchu"});
            this.agm.Location = new System.Drawing.Point(181, 142);
            this.agm.Name = "agm";
            this.agm.Size = new System.Drawing.Size(157, 21);
            this.agm.TabIndex = 10;
            this.agm.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // jenis
            // 
            this.jenis.FormattingEnabled = true;
            this.jenis.Items.AddRange(new object[] {
            "Laki - Laki",
            "Perempuan"});
            this.jenis.Location = new System.Drawing.Point(181, 168);
            this.jenis.Name = "jenis";
            this.jenis.Size = new System.Drawing.Size(157, 21);
            this.jenis.TabIndex = 11;
            // 
            // asl
            // 
            this.asl.Location = new System.Drawing.Point(181, 202);
            this.asl.Name = "asl";
            this.asl.Size = new System.Drawing.Size(159, 20);
            this.asl.TabIndex = 12;
            this.asl.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // instansi
            // 
            this.instansi.AutoSize = true;
            this.instansi.Location = new System.Drawing.Point(492, 50);
            this.instansi.Name = "instansi";
            this.instansi.Size = new System.Drawing.Size(100, 13);
            this.instansi.TabIndex = 13;
            this.instansi.Text = "Instansi yang Dipilih";
            this.instansi.Click += new System.EventHandler(this.label8_Click);
            // 
            // SD
            // 
            this.SD.AutoSize = true;
            this.SD.Location = new System.Drawing.Point(494, 76);
            this.SD.Name = "SD";
            this.SD.Size = new System.Drawing.Size(41, 17);
            this.SD.TabIndex = 14;
            this.SD.Text = "SD";
            this.SD.UseVisualStyleBackColor = true;
            this.SD.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // SMP
            // 
            this.SMP.AutoSize = true;
            this.SMP.Location = new System.Drawing.Point(494, 99);
            this.SMP.Name = "SMP";
            this.SMP.Size = new System.Drawing.Size(49, 17);
            this.SMP.TabIndex = 15;
            this.SMP.Text = "SMP";
            this.SMP.UseVisualStyleBackColor = true;
            this.SMP.CheckedChanged += new System.EventHandler(this.SMP_CheckedChanged);
            // 
            // SMA
            // 
            this.SMA.AutoSize = true;
            this.SMA.Location = new System.Drawing.Point(494, 122);
            this.SMA.Name = "SMA";
            this.SMA.Size = new System.Drawing.Size(49, 17);
            this.SMA.TabIndex = 16;
            this.SMA.Text = "SMA";
            this.SMA.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(223, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 45);
            this.button1.TabIndex = 17;
            this.button1.Text = "Tampilkan";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(493, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Kelas yang dipilih";
            // 
            // reguler
            // 
            this.reguler.AutoSize = true;
            this.reguler.Location = new System.Drawing.Point(494, 198);
            this.reguler.Name = "reguler";
            this.reguler.Size = new System.Drawing.Size(63, 17);
            this.reguler.TabIndex = 19;
            this.reguler.Text = "Reguler";
            this.reguler.UseVisualStyleBackColor = true;
            // 
            // unggulan
            // 
            this.unggulan.AutoSize = true;
            this.unggulan.Location = new System.Drawing.Point(495, 221);
            this.unggulan.Name = "unggulan";
            this.unggulan.Size = new System.Drawing.Size(72, 17);
            this.unggulan.TabIndex = 20;
            this.unggulan.Text = "Unggulan";
            this.unggulan.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Location = new System.Drawing.Point(396, 303);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 47);
            this.button2.TabIndex = 21;
            this.button2.Text = "Keluar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // table1BindingSource
            // 
            this.table1BindingSource.DataMember = "Table1";
            this.table1BindingSource.DataSource = this.tugasoptionalDataSet;
            // 
            // tugasoptionalDataSet
            // 
            this.tugasoptionalDataSet.DataSetName = "tugasoptionalDataSet";
            this.tugasoptionalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // table1TableAdapter
            // 
            this.table1TableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.unggulan);
            this.Controls.Add(this.reguler);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SMA);
            this.Controls.Add(this.SMP);
            this.Controls.Add(this.SD);
            this.Controls.Add(this.instansi);
            this.Controls.Add(this.asl);
            this.Controls.Add(this.jenis);
            this.Controls.Add(this.agm);
            this.Controls.Add(this.almt);
            this.Controls.Add(this.tanggal);
            this.Controls.Add(this.name);
            this.Controls.Add(this.asal);
            this.Controls.Add(this.jk);
            this.Controls.Add(this.agama);
            this.Controls.Add(this.alamat);
            this.Controls.Add(this.ttl);
            this.Controls.Add(this.nama);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.table1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tugasoptionalDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label nama;
        private System.Windows.Forms.Label ttl;
        private System.Windows.Forms.Label alamat;
        private System.Windows.Forms.Label agama;
        private System.Windows.Forms.Label jk;
        private System.Windows.Forms.Label asal;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox tanggal;
        private System.Windows.Forms.TextBox almt;
        private System.Windows.Forms.ComboBox agm;
        private System.Windows.Forms.ComboBox jenis;
        private System.Windows.Forms.TextBox asl;
        private System.Windows.Forms.Label instansi;
        private System.Windows.Forms.CheckBox SD;
        private System.Windows.Forms.CheckBox SMP;
        private System.Windows.Forms.CheckBox SMA;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox reguler;
        private System.Windows.Forms.CheckBox unggulan;
        private System.Windows.Forms.Button button2;
        private tugasoptionalDataSet tugasoptionalDataSet;
        private System.Windows.Forms.BindingSource table1BindingSource;
        private tugasoptionalDataSetTableAdapters.Table1TableAdapter table1TableAdapter;
    }
}

